﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;

namespace ServiceBusFeaturesCXP
{
    class Program
    {
        static string connectionString = "<ENTER CONNECTION STRING HERE>";
       //static string queueName = "deadletterqueue";
        static string queueName = "deferredmessages";
        static async Task Main()
        {
            //send a message to the queue
            await SendMessageAsync();
            //await ExceedDeliveryCount();
            await DeferMessage();
        }

        static async Task SendMessageAsync()
        {
            // create a Service Bus client 
            await using (ServiceBusClient client = new ServiceBusClient(connectionString))
            {
                // create a sender for the queue 
                ServiceBusSender sender = client.CreateSender(queueName);

                // create a message that we can send
                ServiceBusMessage message = new ServiceBusMessage("Hello world!");

                // send the message
                await sender.SendMessageAsync(message);
                Console.WriteLine($"Sent message with message ID= {0} to the queue: {1}", message.MessageId, queueName);
            }
        }

        static async Task ExceedDeliveryCount()
        {
            await using (ServiceBusClient client = new ServiceBusClient(connectionString))
            {
                ServiceBusReceiver receiver = client.CreateReceiver(queueName);

                for (int i = 0; i < 2; i++)
                {
                    ServiceBusReceivedMessage receivedMessage = await receiver.ReceiveMessageAsync();
                    await receiver.AbandonMessageAsync(receivedMessage);
                    Console.WriteLine("Message ID {0} Abandoned {1} times", receivedMessage.MessageId, receivedMessage.DeliveryCount);
                }
            }
        }

        static async Task DeferMessage()
        {
            await using (ServiceBusClient client = new ServiceBusClient(connectionString))
            {
                ServiceBusReceiver receiver = client.CreateReceiver(queueName);

                ServiceBusReceivedMessage receivedMessage = await receiver.ReceiveMessageAsync();

                // defer the message, thereby preventing the message from being received again without using the received deferred message API.
                await receiver.DeferMessageAsync(receivedMessage);

                // receive the deferred message by specifying the service set sequence number of the original received message
                Console.WriteLine("Enter 1 if you wish to receive deferred message, Enter 2 to exit");
                int option = Convert.ToInt32(Console.ReadLine());
                if (option == 1)
                {
                    ServiceBusReceivedMessage deferredMessage = await receiver.ReceiveDeferredMessageAsync(receivedMessage.SequenceNumber);
                    await receiver.CompleteMessageAsync(deferredMessage);
                    Console.WriteLine("Received deferred message " + deferredMessage.MessageId);
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Bye Bye you selected Exit");
                    return;
                }
            }
        }

    }
}
